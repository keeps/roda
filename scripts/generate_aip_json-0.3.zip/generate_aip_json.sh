#!/usr/bin/env bash

errcho(){ >&2 echo $@; }

# set -x #echo on

if [[ $# -eq 0 ]] ; then
	errcho "Usage: $0 path_to_aip1 path_to_aip2 ..."
	exit 1
fi

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

for arg in "$@"
do
    if [[ -d $arg ]]; then
        if [[ -f $arg/METS.xml ]]; then
            # echo "$arg is an AIP."
            java -jar $DIR/saxon9he.jar -xsl:$DIR/generate_aip_json.xsl -s:"$arg/METS.xml" -o:"$arg/aip.json"
            echo "[INFO] Generated $arg/aip.json."
        else
            errcho "[WARNING] $arg is not an AIP. $arg/METS.xml doesn't exist."
        fi
    else
        errcho "[WARNING] $arg is not an AIP."
    fi
done
